package ee.ttu.algoritmid.horseracing;

public interface RacingDuo {

    public RacingParticipant getJockey();

    public RacingParticipant getHorse();

}
